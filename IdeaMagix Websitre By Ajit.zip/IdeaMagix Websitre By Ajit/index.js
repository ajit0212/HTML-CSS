const accordion=document.getElementsByClassName("accordion-content");

for (let index = 0; index < accordion.length; index++) {
    accordion[index].addEventListener("click",function(){
        this.classList.toggle('active')
    })
    
}
$(document).ready(function(){
    $(".icon").click(function(){
        $("ul").toggleClass("show")
    })
})

$('.owl-carousel').owlCarousel({
    loop:true,
    lazyLoad: true,
    margin:10,
    autoplay:true,
    autoplayTimeout:2000,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:2
        },
        1000:{
            items:3
        }
    }
    });

document.getElementById("year").innerHTML= new Date().getFullYear();
